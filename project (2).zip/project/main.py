import json

def read_student():

    try:
        # Open the file as readonly mode
        file = open("studentData.json", "r")

        # Read data from file
        file_content_as_text = file.read()

        # convert json text to array
        student = json.loads(file_content_as_text)

        # close the file
        file.close()

        return student
    except:
        return []


def write_student(student):

    # Open the file with write permission
    file = open("studentData.json", "w+")

    # Convert python list to json text
    json_text = json.dumps(student, indent=4)

    # save the text to the studentData.json file
    file.writelines(json_text)

    # close the file
    file.close()


def add_student(name, id, sec,course,status):

    # Read all student info from file
    student_array = read_student()

    # Create new student dict/item
    newStudent = dict()
    newStudent['name'] = name
    newStudent['id'] = id
    newStudent['sec'] = sec
    newStudent['courses'] = course
    newStudent['status'] = status

    # add the new student to the student array
    student_array.append(newStudent)

    # Write the new array into the file
    write_student(student_array)


def view_student_list():

    # Read all student info from file
    student_array = read_student()
    found = False
    print("\n------------Students List-------------\n")
    for student in student_array:
        # show Student List
        print("Name : {}".format(student.get("name")))
        print("ID : {}\n".format(student.get("id")))
        found = True
    if(not found):
        print(f"\nNo Student Data Found With This ID : {query}\n")

    print("\n----------------------------------------\n")



def search_student( query ):

    # Read all student info from file
    student_array = read_student()
    found = False
    for student in student_array:

        # if  ID matches, show details
        if student.get("id") == query :
            print("\n------------Student Details-------------\n")
            print("Name : {}".format(student.get("name")))
            print("ID : {}".format(student.get("id")))
            print("Section : {}".format(student.get("sec")))
            print("Courses : {}".format(student.get("courses")))
            print("Registration Status : {}".format(student.get("status")))
            print("\n----------------------------------------\n")
            found = True
            break;
    if(not found):
        print(f"\nNo Student Data Found With This ID : {query}\n")



def update_student( query ):

    # Read all student info from file
    student_array = read_student()
    found = False
    for student in student_array:

        # if  ID matches, show status
        if student.get("id") == query :

            print("\nPrevious Registration Status : {}".format(student.get("status")))
            c_status = str(input("Set Current Registration Status : "))
            student['status'] = c_status;
            write_student(student_array)
            print("\nRegistration Status Updated Successfully\n")
            found = True
            break;

    if (not found):
        print(f"\nNo Student Data Found With This ID : {query}\n")


def delete_student( query ):

    # Read all student info from file
    student_array = read_student()
    delete = False
    for student in student_array:
        # if  ID matches, delete Record
        if student.get("id") == query :

            student.pop('name', None)
            student.pop('id', None)
            student.pop('sec', None)
            student.pop('courses', None)
            student.pop('status', None)

            write_student(remove_empty_from_dict(student_array))

            print("\nRecord Deleted Successfully\n")
            delete = True
            break;

    if (not delete):
        print(f"\nNo Student Data Found With This ID : {query}\n")


# Check empty dict and remove key
def remove_empty_from_dict(d):
    if type(d) is dict:
        return dict((k, remove_empty_from_dict(v)) for k, v in d.items() if v and remove_empty_from_dict(v))
    elif type(d) is list:
        return [remove_empty_from_dict(v) for v in d if v and remove_empty_from_dict(v)]
    else:
        return d


while True:
    print("1. Add Student")
    print("2. View All Student List")
    print("3. Search Student With Detailed Info")
    print("4. Update Registration Status")
    print("5. Delete Registration Record")

    choice = int(input("Enter Your Choice : "))

    if choice == 1:
        name = str(input("\nEnter Student Name: "))
        id = str(input("Enter ID: "))
        sec = str(input("Section: "))
        course = str(input("Enter Course Code Separate With Comma : "))
        status = str(input("Registration Status : "))
        add_student(name, id, sec,course,status)
        print("\nStudent Data Added Successfully\n")

    elif choice == 2:
        view_student_list()

    elif choice == 3:
        query = str(input("Enter Student ID : "))
        search_student(query)

    elif choice == 4:
        query = str(input("Enter Student ID : "))
        update_student(query)

    elif choice == 5:
        query = str(input("Enter Student ID : "))
        delete_student(query)

    else:
        print("\nWrong Choice\n")